Program nale�y uruchamia� za pomoc� polecenia python3. 
Dodatkowo trzeba poda� 3 argumenty:
1. plik wej�ciowy w formacie TGA
2. nazwa pliku wyj�ciowego w formacie TGA
3. Liczba kolor�w.

Przyk�adowe wywo�anie:
python3 kwantyzacja_wektorowa.py example0.tga result.tga 5

Wynikowe zdj�cie b�dzie zawiera�o 2^(liczba kolor�w) najwa�niejszych kolor�w wej�ciowego obrazu.